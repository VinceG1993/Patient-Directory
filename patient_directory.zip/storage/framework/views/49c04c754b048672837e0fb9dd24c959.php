<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h2 class="text-center">Doctors List</h2>
    <button class="btn btn-success mb-3" data-bs-toggle="modal" data-bs-target="#addDoctorModal"><i class="bi bi-plus-lg"></i> Add New Doctor</button>
    <table class="table table-bordered">
        <thead class="table-dark">
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Clinic Address</th>
                <th>Deposit Required</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($doctor->id); ?></td>
                    <td><?php echo e($doctor->name); ?></td>
                    <td><?php echo e($doctor->email); ?></td>
                    <td><?php echo e($doctor->phone_number); ?></td>
                    <td><?php echo e($doctor->clinic_address); ?></td>
                    <td><?php echo e($doctor->deposit_required ? 'Yes' : 'No'); ?></td>
                    <td>
                        <button class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#editDoctorModal<?php echo e($doctor->id); ?>">Edit</button>
                        <form action="<?php echo e(route('doctors.destroy', $doctor->id)); ?>" method="POST" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure?')">Delete</button>
                        </form>
                        <a href="<?php echo e(route('doctors.appointments', $doctor->id)); ?>" class="btn btn-sm btn-primary">View Appointments</a>
                    </td>
                </tr>

                <!-- Edit Modal -->
                <div class="modal fade" id="editDoctorModal<?php echo e($doctor->id); ?>" tabindex="-1" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Edit Doctor</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>
                            <div class="modal-body">
                                <form action="<?php echo e(route('doctors.update', $doctor->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>

                                    <div class="mb-3">
                                        <label>Name</label>
                                        <input type="text" name="name" class="form-control" value="<?php echo e($doctor->name); ?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label>Email</label>
                                        <input type="email" name="email" class="form-control" value="<?php echo e($doctor->email); ?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label>Phone</label>
                                        <input type="text" name="phone_number" class="form-control" value="<?php echo e($doctor->phone_number); ?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label>Clinic Address</label>
                                        <input type="text" name="clinic_address" class="form-control" value="<?php echo e($doctor->clinic_address); ?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label>Deposit Required</label>
                                        <select name="deposit_required" class="form-select">
                                            <option value="1" <?php echo e($doctor->deposit_required ? 'selected' : ''); ?>>Yes</option>
                                            <option value="0" <?php echo e(!$doctor->deposit_required ? 'selected' : ''); ?>>No</option>
                                        </select>
                                    </div>

                                    <button type="submit" class="btn btn-success">Save Changes</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End Modal -->

                <!-- Add Doctor Modal -->
                <div class="modal fade" id="addDoctorModal" tabindex="-1" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Add New Doctor</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>
                            <div class="modal-body">
                                <form id="doctorAdd" action="<?php echo e(route('doctors.store')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>

                                    <div class="mb-3">
                                        <label>Name</label>
                                        <input type="text" name="name" class="form-control" required>
                                    </div>
                                    <div class="mb-3">
                                        <label>Email</label>
                                        <input type="email" name="email" class="form-control" required>
                                    </div>
                                    <div class="mb-3">
                                        <label>Phone</label>
                                        <input type="text" name="phone_number" class="form-control" required>
                                    </div>
                                    <div class="mb-3">
                                        <label>Clinic Address</label>
                                        <input type="text" name="clinic_address" class="form-control" required>
                                    </div>
                                    <div class="mb-3">
                                        <label>Deposit Required</label>
                                        <select name="deposit_required" class="form-select">
                                            <option value="1">Yes</option>
                                            <option value="0">No</option>
                                        </select>
                                    </div>
                                    <div class="mb-3">
                                        <label>Password (Min. 6 characters)</label>
                                        <input type="password" name="password" id="password" class="form-control" required>
                                        <div class="invalid-feedback">
                                            Password must be at least 6 characters long.
                                        </div>
                                    </div>

                                    <button type="submit" class="btn btn-success" disabled>Add Doctor</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End Modal -->

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    document.addEventListener("DOMContentLoaded", function () {
        const passwordInput = document.getElementById("password");
        const form = document.getElementById("addDoctorModal");
        const submitButton = form.querySelector("button[type='submit']");

        form.addEventListener("input", function () {
            let allFilled = [...form.querySelectorAll("input, textarea")].every(input => input.value.trim() !== "");
            
            if (allFilled){
                if (passwordInput.value.length < 6) {
                    passwordInput.classList.add("is-invalid");
                    submitButton.disabled = true; 
                } else {
                    passwordInput.classList.remove("is-invalid");
                    submitButton.disabled = false; 
                }
            } else{
                submitButton.disabled = false;
            }
        });

        // Prevent form submission if the password is still invalid
        form.addEventListener("submit", function (event) {
            if (passwordInput.value.length < 6) {
                passwordInput.classList.add("is-invalid");
                event.preventDefault(); // Stop form submission
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\vince\Github\EMR\resources\views/doctors/index.blade.php ENDPATH**/ ?>