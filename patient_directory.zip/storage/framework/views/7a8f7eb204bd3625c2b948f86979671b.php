<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h2 class="text-center">Appointments List</h2>
    <a href="<?php echo e(route('appointments.create')); ?>" class="btn btn-success mb-3">
        <i class="bi bi-plus-lg"></i> New Appointment
    </a>

    <!-- Success Message -->
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <!-- Appointments Table -->
    <div class="table-responsive">
        <table class="table table-hover table-bordered text-center">
            <thead class="table-dark">
                <tr>
                    <th>ID</th>
                    <th>Doctor</th>
                    <th>Patient</th>
                    <th>Date</th>
                    <th>Time</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($appointment->id); ?></td>
                        <td><?php echo e($appointment->doctor->name); ?></td> 
                        <td><?php echo e($appointment->patient->name); ?></td> 
                        <td><?php echo e(\Carbon\Carbon::parse($appointment->appointment_date)->format('F d, Y')); ?></td>
                        <td><?php echo e(\Carbon\Carbon::parse($appointment->appointment_time)->format('h:i A')); ?></td>
                        <td>
                            <span class="badge 
                                <?php echo e($appointment->status == 'Pending' ? 'bg-warning' : 
                                   ($appointment->status == 'Confirmed' ? 'bg-success' : 'bg-danger')); ?>">
                                <?php echo e($appointment->status); ?>

                            </span>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\vince\Github\EMR\resources\views/appointments/index.blade.php ENDPATH**/ ?>