<?php $__env->startSection('title', 'Home - EMR'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <h1 class="text-center">Welcome to the EMR System</h1>
        <p class="text-center">This is the homepage for the EMR system.</p>

        <div class="text-center">
            <a href="<?php echo e(route('appointments.create')); ?>" class="btn btn-primary">Book an Appointment</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\vince\Github\EMR\resources\views/home.blade.php ENDPATH**/ ?>