<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h2 class="text-center">Book an Appointment</h2>
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    <form id="appointmentForm" action="<?php echo e(route('appointments.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        
        <!-- Select Doctor -->
        <div class="mb-3">
            <label for="doctor_id" class="form-label">Select Doctor</label>
            <select class="form-select" id="doctor_id" name="doctor_id" required>
                <option value="">Choose...</option>
                <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($doctor->id); ?>"><?php echo e($doctor->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div> 

        <!-- Select Patient -->
        <div class="mb-3">
            <label for="patient_id" class="form-label">Select Patient</label>
            <select class="form-select" id="patient_id" name="patient_id" required>
                <option value="">Choose...</option>
                <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($patient->id); ?>"><?php echo e($patient->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <!-- Select Date -->
        <div class="mb-3">
            <label for="appointment_date" class="form-label">Select Date</label>
            <input type="text" class="form-control" id="appointment_date" name="appointment_date" autocomplete="off" required disabled>
        </div>

        <!-- Select Time -->
        <div class="mb-3">
            <label for="appointment_time" class="form-label">Select Time</label>
            <select class="form-select" id="appointment_time" name="appointment_time" autocomplete="off" required disabled>
                <option value="">Choose...</option>
            </select>
        </div>

        <!-- Select Status -->
        <div class="mb-3">
            <label for="status" class="form-label">Status</label>
            <select class="form-select" id="status" name="status" required>
                <option value="Pending" selected>Pending</option>
                <option value="Confirmed">Confirmed</option>
                <option value="Cancelled">Cancelled</option>
            </select>
        </div>

        <!-- Deposit status -->
        <div class="mb-3">
            <label for="deposit_paid" class="form-label">Deposit Paid</label>
            <select class="form-select" id="deposit_paid" name="deposit_paid" required>
                <option value="1" selected>true</option>
                <option value="0">false</option>
            </select>
        </div>

        <!-- Availability Message -->
        <div id="availabilityMessage" class="mt-3"></div>

        <!-- Submit Button -->
        <button type="submit" class="btn btn-primary w-100" >Book Appointment</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>

<script>
    $(document).ready(function () {
    let availableDays = []; // Declare globally to store available days

    // Fetch available dates when a doctor is selected
    $('#doctor_id').on('change', function () {
        let doctorId = $(this).val();

        if (doctorId) {
            $.ajax({
                url: "<?php echo e(route('doctor.getAvailableDates')); ?>",
                type: "GET",
                data: { doctor_id: doctorId },
                success: function (response) {
                    if (response.availableDays) {
                        availableDays = response.availableDays.map(day => day.toLowerCase());

                        $("#appointment_date").datepicker("destroy").datepicker({
                            dateFormat: "yy-mm-dd",
                            beforeShowDay: function (date) {
                                let dayName = date.toLocaleDateString('en-US', { weekday: 'long' }).toLowerCase();
                                return [availableDays.includes(dayName)];
                            },
                            minDate: 0
                        });

                        $("#appointment_date").prop("disabled", false); // Enable date field
                    }
                }
            });
        } else {
            $("#appointment_date").datepicker("destroy").prop("disabled", true);
            $("#appointment_time").prop("disabled", true);
        }
    });

    // Fetch available time slots when a date is selected
    $('#appointment_date').on('change', function () {
        let doctorId = $('#doctor_id').val();
        let selectedDate = $(this).val();

        if (doctorId && selectedDate) {
            $.ajax({
                url: "<?php echo e(route('doctor.getAvailableTimes')); ?>",
                type: "GET",
                data: { doctor_id: doctorId, appointment_date: selectedDate },
                success: function (response) {
                    let timeDropdown = $('#appointment_time');
                    timeDropdown.empty().prop('disabled', false);

                    if (response.availableTimes.length > 0) {
                        timeDropdown.append('<option value="">Select Time</option>');
                        response.availableTimes.forEach(time => {
                            timeDropdown.append(`<option value="${time}">${time}</option>`);
                        });
                    } else {
                        timeDropdown.append('<option value="">No available times</option>');
                        timeDropdown.prop('disabled', true);
                    }
                }
            });
        }
    });
    
    function validateForm() {
        var isValid = true;
        $('.form-field').each(function() {
            if ( $(this).val() === '' )
                isValid = false;
        });
        return isValid;
    }

    // Check if selected time slot is available
    /*$('#appointment_time').on('change', function () {
        let doctorId = $('#doctor_id').val();
        let selectedDate = $('#appointment_date').val();
        let selectedTime = $(this).val();

        if (doctorId && selectedDate && selectedTime) {
            $.ajax({
                url: "<?php echo e(route('dac.checkAvailability')); ?>",
                type: "GET",
                data: { doctor_id: doctorId, appointment_date: selectedDate, appointment_time: selectedTime },
                success: function (response) {
                    if (response.available) {
                        $('#availabilityMessage').html('<div class="alert alert-success">Doctor is available!</div>');
                        $('button[type="submit"]').prop('disabled', false);
                    } else {
                        $('#availabilityMessage').html('<div class="alert alert-danger">Doctor is not available. Please choose another time.</div>');
                        $('button[type="submit"]').prop('disabled', true);
                    }
                }
            });
        }
    });*/
});

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\vince\Github\EMR\resources\views/appointments/create.blade.php ENDPATH**/ ?>